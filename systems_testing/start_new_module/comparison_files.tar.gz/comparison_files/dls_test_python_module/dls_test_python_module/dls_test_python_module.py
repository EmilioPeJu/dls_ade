def main():
    print "Hello world from dls_test_python_module"
