add helper code

more code
