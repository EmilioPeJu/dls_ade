def main():
    print("Hello world from dls_testpythonmod")
