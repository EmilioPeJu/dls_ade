from setuptools import setup
test changes
some more changes
test changes
more changes
test changes
# these lines allow the version to be specified in Makefile.private
import os
version = os.environ.get("MODULEVER", "0.0")

setup(
#    install_requires = ['cothread'], # require statements go here
    name = 'dls_testpythonmod',
    version = version,
    description = 'Module',
    author = 'lkz95212',
    author_email = 'lkz95212@fed.cclrc.ac.uk',
    packages = ['dls_testpythonmod'],
#    entry_points = {'console_scripts': ['test-python-hello-world = dls_testpythonmod.dls_testpythonmod:main']}, # this makes a script
#    include_package_data = True, # use this to include non python files
    zip_safe = False
    )
