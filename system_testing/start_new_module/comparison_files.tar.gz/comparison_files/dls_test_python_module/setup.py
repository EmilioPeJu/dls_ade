from setuptools import setup

# these lines allow the version to be specified in Makefile.private
import os
version = os.environ.get("MODULEVER", "0.0")

setup(
#    install_requires = ['cothread'], # require statements go here
    name = 'dls_test_python_module',
    version = version,
    description = 'Module',
    author = 'USER_LOGIN_NAME',
    author_email = 'USER_LOGIN_NAME@fed.cclrc.ac.uk',
    packages = ['dls_test_python_module'],
#    entry_points = {'console_scripts': ['test-python-hello-world = dls_test_python_module.dls_test_python_module:main']}, # this makes a script
#    include_package_data = True, # use this to include non python files
    zip_safe = False
    )
